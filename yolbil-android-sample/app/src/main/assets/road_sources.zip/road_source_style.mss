#adres {
  marker-placement: point;
  marker-type: ellipse;
  marker-width: 0;
  marker-line-width: 0;
  marker-opacity: 0;

  [zoom >= 14][zoom < 15] {
    marker-width: 6;
    marker-fill: #ff00ff;
    marker-line-color: #000000;
    marker-line-width: 1.8;
    marker-opacity: 1;
    marker-allow-overlap: true;
  }

  [zoom >= 15][zoom < 16] {
    marker-width: 8;
    marker-fill: #ff00ff;
    marker-line-color: #000000;
    marker-line-width: 1.8;
    marker-opacity: 1;
    marker-allow-overlap: true;
  }

  [zoom >= 16][zoom < 18] {
    marker-width: 10;
    marker-fill: #ff00ff;
    marker-line-color: #000000;
    marker-line-width: 2.1;
    marker-opacity: 1;
    marker-allow-overlap: true;
  }

  [zoom >= 18] {
    marker-width: 13;
    marker-fill: #ff00ff;
    marker-line-color: #000000;
    marker-line-width: 2.4;
    marker-opacity: 1;
    marker-allow-overlap: true;
  }
 
}
